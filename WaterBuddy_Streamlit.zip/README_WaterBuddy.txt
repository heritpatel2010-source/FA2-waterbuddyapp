WATERBUDDY - STREAMLIT WEB APP

Files:
- app.py: main Streamlit application
- requirements.txt: required Python package

Run on your computer:
1. Install Python.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py
5. Open the local URL shown in the terminal.

Deploy on Streamlit Community Cloud:
1. Create a GitHub repository.
2. Upload app.py and requirements.txt to the repository root.
3. In Streamlit Community Cloud, choose New app.
4. Select your repository, branch, and app.py as the main file.
5. Deploy.

IMPORTANT:
This version is designed for Streamlit/web hosting and does not use Tkinter.
Streamlit session state keeps entries while the browser session is active. For a
long-term deployed app, connect a database or add persistent cloud storage.
